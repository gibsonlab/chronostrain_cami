Escherichia_coli_custom: Constructed from UMB analysis (fim + O:H serotyping + MLST + shigatoxin)
Escherichia_coli: MLST + MetaPhlAn mpa_vJun23_CHOCOPhlAnSGB_202307
Staphylococcus_aureus: MLST + MetaPhlAn mpa_vJun23_CHOCOPhlAnSGB_202307
Streptococcus_pneumoniae: MLST + MetaPhlAn mpa_vJun23_CHOCOPhlAnSGB_202307
Klebsiella_pneumoniae: MLST + MetaPhlAn mpa_vJun23_CHOCOPhlAnSGB_202307
